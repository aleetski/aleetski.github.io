#include <stdio.h>
#include <iostream>
using namespace std;
class myException
{
    private:
        int errCode;
        string msg;
    public:
        void seterrCode(int x)
        {
            errCode = x;
        }
        void setmsg(string m)
        {
            msg=m;
        }
        int geterrCode()
        {
            return errCode;
        }
        string getmsg()
        {
            return msg;
        }
};
int main()
{
    myException me;
    int i = 0;
    
    try{
        for(i = 0;i<20;i++)
        if(i>10)
        {
            me.seterrCode(-1);
            me.setmsg("Value Greater than 10");
            throw me;
        }
    }
    catch(myException &ex)
    {
        cout<<"Error Code: "<<ex.geterrCode();
        cout<<" Error Msg: "<<ex.getmsg();
    }
    
    cout<<"\nProgram Terminated Successfully\n";
    return 0;
}