#include<iostream>

using namespace std;

class FM2;
class FM1
{
private:
	string fname1;
	string lname1;
	int income1;
public:
	FM1(string f1, string l1, int inc):fname1(f1),  lname1(l1), income1(inc)
	{}
	FM1()
	{
		fname1 = "First1 ";
		lname1 = "Last1 ";
		income1 = 10000;
	}
	friend class FM2;
	int getIncome()
	{
		return income1;
	}
};

class FM2
{
private:
	string fname2;
	string lname2;
	int income2;
	int tax_rate;
public:
	FM2(string f2, string l2, int inc, int tr) :fname2(f2), lname2(l2), income2(inc)
	{
		tax_rate = tr;
	}
	FM2()
	{
		fname2 = "First2 ";
		lname2 = "Last2 ";
		income2 = 20000;
		tax_rate = 2;
	}
	float calcTax(FM1 &f)
	{	
		return ((float)tax_rate/100) * (float)(f.income1 + this->income2);
	}
	float getTaxRate()
	{
		return tax_rate;

	}
	int getIncome()
	{
		return income2;
	}
};

int main()
{
	FM1 obj1("Albert","John",55026);
	FM2 obj2("Abdul","Moiz",120000,5);

	cout << "Tax rate: " << obj2.getTaxRate()<<endl;
	cout << "Income of Member 1: " << obj1.getIncome()<<endl;
	cout << "Income of Member 2: " << obj2.getIncome() << endl;
	cout << "Tax Amount: " << obj2.calcTax(obj1)<<endl;

	system("pause");
	return 0;
}