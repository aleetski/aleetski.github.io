#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
    
    int *jaggedArray[3];
    
    jaggedArray[0] = new int[5] { 1, 3, 5, 7, 9 };
    jaggedArray[1] = new int[4] { 0, 2, 4, 6 };
    jaggedArray[2] = new int[2] { 11, 22 };

    cout<<jaggedArray[0][2]<<endl;

    cout<<*(jaggedArray[0]+3)<<endl;



    int jagged_row0[] = {1,2};
    int jagged_row1[] = {3,4,5};
    int *jagged[] = { jagged_row0, jagged_row1 };

    int i=0;
    cout<<jagged[i][1];

    return 0;
}