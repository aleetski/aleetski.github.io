//----------------Task 3-------------------------
#include<iostream>
using namespace std;
template <class T>
class subRange
{
public:
  subRange( T, T );
  T getValue( );
  T getLowerRange(){return lower;}
  T getUpperRange(){return upper;}
private:
  T lower, upper;
};

template <class T>
subRange<T>::subRange( T low, T high )
{
  lower = low;
  upper = high;
}

template <class T>
T subRange<T>::getValue()
{
  T v;
  cout << "Enter value [ " << lower << ", " << upper << " ]: ";
  cin >> v;
  if(v<lower || v>upper)
    throw "Value out of Range !";
  return v;
}

int main()
{
  int int_return;
  float float_return;
  char char_return;
  //----------Integer Type -----------------
  subRange<int> x_int(1,10);
  
 do{
   
    try
    { 
       int_return = x_int.getValue( );
      cout << int_return << endl;
    }
    catch(const char* err)
    {
      cout<<err<<endl;
    }
 } while (int_return<x_int.getLowerRange() || int_return>x_int.getUpperRange());

 //------------Float Type-----------------------
 subRange<float> x_float(2.1,10.5);
 do{
   
    try
    { 
       float_return = x_float.getValue( );
      cout << float_return << endl;
    }
    catch(const char* err)
    {
      cout<<err<<endl;
    }
 } while (float_return<x_float.getLowerRange() || float_return>x_float.getUpperRange());

 //-------------------CHAR Type------------------
 subRange<char> x_char('a','f');
 do{
   
    try
    { 
       char_return = x_char.getValue( );
      cout << char_return << endl;
    }
    catch(const char* err)
    {
      cout<<err<<endl;
    }
 } while (char_return<x_char.getLowerRange() || char_return>x_char.getUpperRange());
  return 0;
}
//----------------Task 2-------------------------
/*
#include <iostream>
#include <new>
using namespace std;
class array
{
public:
    array( int = 1 );
// other functions not needed for this assignment
private:
    int* elts;
    int count;
};
array::array( int sz )
{
    count = sz;
    elts = new int[ count ];
}
int main( )
{   
    array* ptr[10];
    
    for ( int i = 0; i < 10; i++ )
    {
        try
        {
            ptr[i] = new array( 50000000000000000000000000000000L );
        }
        catch (const std::bad_alloc& e) 
        {
            std::cout << "Allocation failed: " << e.what() << '\n';
          
        }

    }
    return 0;
}
*/


//----------------Task 1-------------------------
/*#include<iostream>
using namespace std;

class subRange
{
public:
  subRange( int, int );
  int getValue( );
  int getLowerRange(){return lower;}
  int getUpperRange(){return upper;}
private:
  int lower, upper;
};

subRange::subRange( int low, int high )
{
  lower = low;
  upper = high;
}
int subRange::getValue()
{
  int v;
  cout << "Enter value [ " << lower << ", " << upper << " ]: ";
  cin >> v;
  if(v<lower || v>upper)
    throw "Value out of Range !";
  return v;
}
int main()
{
  int y;
  subRange x(1,10);
  
 do{
   
    try
    { 
       y = x.getValue( );
      cout << y << endl;
    }
    catch(const char* err)
    {
      cout<<err<<endl;
    }
 } while (y<x.getLowerRange() || y>x.getUpperRange());
  return 0;
}
*/