#include<iostream>
using namespace std;
template<typename T>
class myCalculator
{
public:
	myCalculator()
	{
		cout << "Welcome to My Calculator" << endl;
		testCalculator();
	}
	int testCalculator()
	{
		while (1)
		{


			switch (menu())
			{

			case 1:
				input_data();
				cout << "Sum: " << sum() << endl;
				break;
			case 2:
				input_data();
				cout << "Subtract: " << subtract() << endl;
				break;
			case 3:
				input_data();
				cout << "Product: " << product() << endl;
				break;
			case 4:
				input_data();
				cout << "Division: " << division() << endl;
				break;
			case 5:
				input_num1();
				cout << "Square (num1): " << square_num1() << endl;
				break;
			case 6:
				input_num2();
				cout << "Square (num2): " << square_num2() << endl;
				break;
			case 7:
			default:
				return 0;
			}
			getchar();
			system("pause");
			system("cls");
		}
	}
	T sum()
	{
		return num1 + num2;
	}
	T subtract()
	{
		return num1 - num2;
	}
	T product()
	{
		return num1 * num2;
	}
	double division()
	{
		return (num1 / num2);
	}
	T square_num1()
	{
		return num1 * num1;
	}
	T square_num2()
	{
		return num2 * num2;
	}
	void input_data()
	{
		cout << "Enter number 1 ";
		cin >> num1;

		cout << "Enter number 2 ";
		cin >> num2;
	}
	void input_num1()
	{
		cout << "Enter number 1 ";
		cin >> num1;

		
	}
	void input_num2()
	{
		
		cout << "Enter number 2 ";
		cin >> num2;
	}
	int menu()
	{
		cout << "Menu Options " << endl;
		cout << "1: Sum" << endl;
		cout << "2: Subtract" << endl;
		cout << "3: Product" << endl;
		cout << "4: Division" << endl;
		cout << "5: Square (number1)" << endl;
		cout << "6: Square (number2)" << endl;
		cout << "7: Exit" << endl;

		int choice;
		cout << "Enter Option: ";
		cin >> choice;
		return choice;
	}
private:
	T num1;
	T num2;

};
int main()
{
	myCalculator<int> int_obj;
	
	system("pause");
	return 0;
}