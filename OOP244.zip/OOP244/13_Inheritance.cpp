#include <iostream>

using namespace std;

class baseClass1
{
public:
	int sum(int x, int y)
	{
		return x + y;
	}
	baseClass1()
	{
		cout << "This is a Base Class 1 Constructor" << endl;
	}
};
class baseClass2
{
public:
	int sum(int x, int y)
	{
		return x + y;
	}
	baseClass2()
	{
		cout << "This is a Base Class 2 Constructor" << endl;
	}
};
class derivedClass : public baseClass1, public baseClass2
{
public:
	/*int sum(int x, int y)
	{
		return 2*(x + y);
	}*/
	derivedClass()
	{
		cout << "This is a Derived Class Constructor" << endl;
	}
};
int main()
{
	derivedClass dObj;
	
	
	cout << dObj.baseClass2::sum(3, 4) << endl;

	
	system("pause");
	return 0;
}