#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    // Get a file name from the user and dump its content on the screen
    FILE* fp;
    int lineCounter = 0, charCount = 0;
    char fileName[51];
    char line[81];

    printf("Please enter a file name >");
    gets(fileName);

    fp = fopen(fileName, "r");
    if (!fp)
        printf("I couldn't find the file!");
    else
    {
        while(fgets(line, 81, fp))
        {
          printf("%s", line);
          lineCounter = lineCounter + 1;
          charCount = charCount + strlen(line) - 1;
        }
    }

printf("\n---------------------------------\n");
printf("I read %d lines and %d characters from the file", lineCounter, charCount);
fclose(fp);
}
