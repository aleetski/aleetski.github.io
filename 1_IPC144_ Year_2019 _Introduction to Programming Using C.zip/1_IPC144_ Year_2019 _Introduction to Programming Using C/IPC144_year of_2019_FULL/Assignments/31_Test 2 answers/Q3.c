#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STR_LEN 1024
#define STR_LEN 200

//Develop a code that gets two same length strings from the user and reports the number of characters that they have different.


int main()
{
    int i, stringLength1, stringLength2;
    char safeStr[MAX_STR_LEN];
    char str1[STR_LEN + 1];
    char str2[STR_LEN + 1];
    int diff = 0;

    printf("\nPlease enter the first string (allowed length is %d characters): ", STR_LEN);
    gets(safeStr);
    strncpy(str1, safeStr, STR_LEN);

    printf("Please enter the second string (allowed length is %d characters): ", STR_LEN);
    gets(safeStr);
    strncpy(str2, safeStr, STR_LEN);

	  stringLength1 = strlen(str1);
	  stringLength2 = strlen(str2);
	if (stringLength1 == stringLength2)
  {
    i = 0;
    while (str1[i])
    {
        if (str1[i] != str2[i])
            diff = diff + 1;
        i = i + 1;
    }

  if ( diff >= 1)
    printf("The two strings have %d differences" , diff);
  else 
    printf("The two strings are the same");
  }
  else printf("The two strings should have the same length! please try again!");

}


