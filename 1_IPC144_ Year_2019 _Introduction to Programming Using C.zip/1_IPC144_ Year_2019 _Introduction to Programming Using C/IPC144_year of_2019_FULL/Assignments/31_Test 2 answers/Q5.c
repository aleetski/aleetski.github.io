#include <stdio.h>
#include <stdlib.h>
#define ARRAY_SIZE 10

int main()
{
    int i, l, r, temp, switchCount = 0;
    int ar[ARRAY_SIZE];
    printf("Please enter 10 integers\n");
    for ( i = 0 ; i < ARRAY_SIZE ; i = i + 1)
        {
            printf("Enter integer %d >", i + 1);
            scanf("%d", &ar[i]);
        }
    printf("\nHere are the numbers you have entered: ");
    for ( i = 0 ; i < ARRAY_SIZE ; i = i + 1)
            printf("%d ", ar[i]);

    for ( l = 0 ; l < ARRAY_SIZE - 1 ; l = l + 1 )
        for ( r = l + 1 ; r < ARRAY_SIZE ; r = r + 1)
            if (ar[l] > ar[r])
            {
                temp = ar[l];
                ar[l] = ar[r];
                ar[r] = temp;
                switchCount = switchCount + 1;
            }

printf("\n\nHere are the numbers you have entered sorted in ascending order:\n");
    for ( i = 0 ; i < ARRAY_SIZE ; i = i + 1)
            printf("%d ", ar[i]);
printf("\nIt took %d swicthes to sort your numbers", switchCount);

    return 0;

}
