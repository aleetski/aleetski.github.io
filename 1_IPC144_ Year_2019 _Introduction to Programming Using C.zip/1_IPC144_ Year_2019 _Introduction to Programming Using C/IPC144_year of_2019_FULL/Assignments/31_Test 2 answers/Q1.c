#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STR_LEN 1024
#define STR_LEN 200


//get a string from user and prints it in the reverse order
//use safe gets to make sure user doesn't mess up memory by going over 200 characters

int main()
{
    int i, stringLength;
    char safeStr[MAX_STR_LEN + 1];
    char str[STR_LEN + 1];
    printf("Please enter a string (max %d chars) and I will reverse the ordering for you: ", STR_LEN);
    gets(safeStr);
    strncpy(str, safeStr, STR_LEN);
    str[STR_LEN] = 0; //in case the user entered a 200+ string
    printf("Here is the string you entered %s", str);

    stringLength = strlen(str);
    printf("\nHere is the string reversed using fore-loop: ");
    for ( i = stringLength - 1 ; i >= 0 ; i = i - 1)
                printf("%c", str[i]);

    return 0;
}
