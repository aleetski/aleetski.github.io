#include <stdio.h>
#include <stdlib.h>
#define ARRAY_SIZE 10

int main()
{
    int i, search;
    int ar[ARRAY_SIZE];
    printf("Please enter 10 integers:\n");
    for ( i = 0 ; i < ARRAY_SIZE ; i = i + 1)
        {
            printf("Enter the integer %d >", i + 1);
            scanf("%d", &ar[i]);
        }
    printf("\n\nEnter the number you are searching for: ");
    scanf("%d", &search);

  for ( i = 0 ; i < ARRAY_SIZE; i = i + 1)    
        if (ar[i] == search)
            printf("%d was found at index %d\n" , search , i);
  

    return 0;

}
