#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STR_LEN 1024
#define STR_LEN 200

//get a string from user and prints out number of lower case and upper case
//char in string. Output should look like:
//Your string has 200 characters, 120 of them are lower case and 25 of them are upper case alphabet letters.
//allowed length for string is 200


int main()
{
    int i; 
    int upperCase = 0 , lowerCase = 0;
    char safeStr[MAX_STR_LEN + 1];
    char str[STR_LEN + 1];

    printf("Please enter a string  (allowed length is %d characters): ", STR_LEN);
    gets(safeStr);
    strncpy(str, safeStr, STR_LEN);
    
    i = 0;
    while(str[i])
    {
      if (str[i]<= 'Z' && str[i]>='A')
        upperCase = upperCase + 1;
      if (str[i]<= 'z' && str[i]>='a')
        lowerCase = lowerCase + 1;
      i = i + 1;
    }

  printf("The string has %d total letters, %d of them are upper case and %d are lower case", i, upperCase, lowerCase);

    return 0;

}
