#include <stdio.h>
#include <stdlib.h>
#define TAX_RATE 0.13

int main()
{
    int x,y;
    printf("enter x and y");
    scanf("%31d%d", &x, &y);
    printf("x is now %d and y is now %d",x , y);
    /*
    float price ;
    float taxIncluded;
    printf("Please enter your price and I will calculate the tax! ");
    scanf("%f", &price);
    taxIncluded = price + price * TAX_RATE;
    printf("\nAn item that costs %.2f$ before tax will be %.2f$ after tax", price, taxIncluded);
    */
    //printf("A %.2f$ item will cost you %.2f$ after tax!", price, taxIncluded);
    //printf("\nThe value of variable taxIncluded is %d\nThe address of variable taxIncluded is %d", taxIncluded, &taxIncluded);
    //printf("\nThe value of variable price is %d\nThe address of variable price is %d", price, &price);
    //printf("\nThe value of variable index is %d\nThe address of variable index is %d", index, &index);


    return 0;

}
