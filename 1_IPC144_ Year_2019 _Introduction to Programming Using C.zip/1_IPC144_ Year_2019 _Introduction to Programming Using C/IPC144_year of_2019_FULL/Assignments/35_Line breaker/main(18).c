#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LINE_LENGTH 80

Some other things to do
/*
1-
change the code to get two output files
if the line is shorter than lineMax, it puts it in output 1
if the line is longer than lineMax, it puts it in output 1

2- If the line starts with uppercase character, put it in output 1, otherwise put it in output2
*/

// develop a code that gets a file name and a line length.
// the code opens the file and breaks any line that is longer than the given length into shorter lines

int main()
{
    FILE* input;
    FILE* output;
    int lineMax, lineCounter = 0;
    char line[MAX_LINE_LENGTH + 1];
    char fileName[51];
    char ch;

    printf("Please enter the input file name >");
    gets(fileName);

    input = fopen(fileName, "r");
    if (!input)
        printf("File doesn't exist! Exiting the program");
    else
    {
        printf("Please enter a line length (max 80) >");
        scanf("%d", &lineMax);
        scanf("%c", &ch);

        printf("Please enter the name of the result file >");
        gets(fileName);
        output = fopen(fileName, "w");

        while(fgets(line, lineMax + 1, input))
        {
            fputs(line, output);

            if (line[strlen(line) -1 ] != 10 )
                fputs("\n", output);
            lineCounter = lineCounter + 1;
        }


    printf("\nI wrote %d lines in the result file", lineCounter);

    fclose(input);
    fclose(output);
    }



}
