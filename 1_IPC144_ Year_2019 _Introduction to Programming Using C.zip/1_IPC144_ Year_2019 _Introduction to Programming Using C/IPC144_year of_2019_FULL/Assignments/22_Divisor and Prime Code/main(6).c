#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int number;
    unsigned int candidate;
    int counter, sum;
    printf("Divisor Finder\n");
    /*
    divisors of 15:
    1 3 5 15

    divisors of 24
    1 2 3 4 6 8 12 24
    */
    do
    {
        counter = 0;
        sum = 0;
        printf("Give me a positive number and I will print all its divisors:\n");
        printf("Enter your number 0 to end > ");
        scanf("%d", &number);

        if ( number >0)
        {
            printf("The divisors of %d are: ", number);

            for (candidate = 1 ; candidate <= number ; candidate = candidate + 1)
                if (number % candidate == 0)
                {
                    printf(" %d ", candidate);
                    counter = counter + 1;
                    sum = sum + candidate;
                }

            printf("\n%d divisors\nsum of divisors: %d\n",  counter, sum);
            if (counter == 2)
                printf("%d is Prime!\n\n", number);
        }


        /*candidate = 1;
        while (candidate <= number)
        {
            if (number % candidate == 0)
                {
                    printf(" %d ", candidate);
                    counter = counter + 1;
                }
            candidate = candidate + 1;
        }*/


    }
    while(number > 0);
    return 0;
}
