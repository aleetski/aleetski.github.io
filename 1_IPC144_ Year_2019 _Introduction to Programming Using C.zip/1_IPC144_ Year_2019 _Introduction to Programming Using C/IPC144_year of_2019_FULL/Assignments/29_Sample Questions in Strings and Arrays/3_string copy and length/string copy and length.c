
#include <stdio.h>
#include <string.h>
#define STR_LEN 50
#define MAX_STR_LEN 1000

int main()
{
    int i;
    char str[STR_LEN + 1];
    char buffer[MAX_STR_LEN + 1];
    // implementing strlen and strcpy
    //strlen
    
    printf("Please enter a string and I will calculate its length: ");
    gets(buffer);
    strncpy(str, buffer , STR_LEN);
    i = 0;
    while (str[i])
        i = i + 1;
    printf("Length of the string is %d", i);
    
    char str2[STR_LEN];
    printf("\n\nNow enter another string and I will copy it into a second variable");
    gets(buffer);
    strncpy(str, buffer , STR_LEN);
    i = 0;
    while (str[i])
        {
            str2[i] = str[i];
            i = i + 1;
        }
    str2[i] = 0;
    printf("This is what you entered     : %s\n", str);
    printf("This is what I copied to str2: %s\n", str2);
    
}
