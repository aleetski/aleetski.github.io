
#include <stdio.h>
#include <string.h>
#define STR_LEN 50
#define MAX_STR_LEN 1000

int main()
{
    int i,j, input_len;
    char temp;
    char str1[STR_LEN + 1];
    char str2[STR_LEN + 1];
    char str1_cpy[STR_LEN + 1];
    char str2_cpy[STR_LEN + 1];
    char buffer[MAX_STR_LEN+1];
    printf("Please enter two strings and I will tell you if they are Anagrams");
    printf("\nPlease enter first string (maximum %d characters)", STR_LEN);
    gets(buffer);
    strncpy(str1, buffer , STR_LEN);
    
    printf("\nPlease enter second string (maximum %d characters)", STR_LEN);
    gets(buffer);
    strncpy(str2, buffer , STR_LEN);
    strcpy(str1_cpy, str1);
    strcpy(str2_cpy, str2);
    
    if (strlen(str1)!=strlen(str2))
    printf("Strings with different length can not be Anagrams!");
    else
    {
    input_len = strlen(str1);
    
    for (i = 0 ; i < input_len -1 ; i = i + 1)
        for (j = i + 1 ; j < input_len ; j = j + 1)
        {
            if (str1[i]>str1[j])
            {
                temp = str1[i];
                str1[i] = str1[j];
                str1[j] = temp;
            }
            
            if (str2[i]>str2[j])
            {
                temp = str2[i];
                str2[i] = str2[j];
                str2[j] = temp;
            }    
        }
    }
    printf("str1 sorted is %s\n", str1);
    printf("str2 sorted is %s\n", str2);
    if (strcmp(str1, str2)==0)
    printf("%s and %s are indeed Anagrams!", str1_cpy, str2_cpy);
    else
    printf("%s and %s are not Anagrams!", str1_cpy, str2_cpy);
    return 0;
}
