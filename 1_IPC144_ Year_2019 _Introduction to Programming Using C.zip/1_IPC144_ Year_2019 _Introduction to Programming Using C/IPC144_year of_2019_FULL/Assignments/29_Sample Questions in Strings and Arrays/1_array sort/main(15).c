#include <stdio.h>
#include <stdlib.h>
#define ARRAY_SIZE 10

int main()
{
    int i, l, r, temp;
    int ar[ARRAY_SIZE];
    printf("Please enter the marks!\n");
    for ( i = 0 ; i < ARRAY_SIZE ; i = i + 1)
        {
            printf("Enter mark for student %d >", i + 1);
            scanf("%d", &ar[i]);
        }
    printf("\n\nHere are the marks you entered: ");
    for ( i = 0 ; i < ARRAY_SIZE ; i = i + 1)
            printf("%d ", ar[i]);

// Sorting the array now
    for ( l = 0 ; l < ARRAY_SIZE - 1 ; l = l + 1 )
        for ( r = l + 1 ; r < ARRAY_SIZE ; r = r + 1)
            if (ar[l] > ar[r])
            {
                temp = ar[l];
                ar[l] = ar[r];
                ar[r] = temp;
            }

printf("\n\nHere are the marks you entered after sorting:\n");
    for ( i = 0 ; i < ARRAY_SIZE ; i = i + 1)
            printf("%d ", ar[i]);
printf(" The worst mark is %d and the top mark is %d ", ar[0], ar[ARRAY_SIZE - 1]);





}
