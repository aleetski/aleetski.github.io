#include <stdio.h>
#include <stdlib.h>
#include  <string.h>

void myStrPrint(char* myStr)
{
    int  i = 0;
    while (myStr[i] != '\0')
    {
        printf("%c", myStr[i]);
        i = i + 1;
    }
}

int main()
{
    int j = 10;
    char ch;
    char myStr[20] = "This is a string";
    char mySecondStr[30] = "This is another string";

    int i = 10;
    // 0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16
    // T   h   i   s       i   s       a       s   0   r   i   n   g   0
    printf("my str is: |%s|\n", myStr);
    printf("my str is: |%s|\n", myStr + 1);

    // inserting a zero in the string

    myStr[8]='0';
    myStr[11]=0; // or mystr[11]='\0';
    printf("\nmy str is: |%s|\n", myStr);
    printf("my str is: |%s|\n\n", &myStr[12]);

    myStrPrint(myStr);
    printf("\n");
    myStrPrint(mySecondStr);

    printf("\n\nTesting puts:\n");
    puts(myStr);
    puts(mySecondStr);

    printf("\n\nTesting puts:\n");
    printf("%s", myStr);
    printf("%s", mySecondStr);

    /*printf("\n\nTesting scanf:\n");
    printf("Please enter you name:");
    scanf("%29s", mySecondStr);
    printf("Hello %s\n", mySecondStr);
    scanf("%29s", mySecondStr);
    printf("Hello %s\n", mySecondStr);
    scanf("%29s", mySecondStr);
    printf("Hello %s\n", mySecondStr);
    //This is my verison of printf %s

    scanf("%c", &ch);*/

    printf("\n\nTesting gets:\n");
    printf("Please enter you name:");
    gets(mySecondStr);
    printf("Hello %s\n", mySecondStr);
    printf("\nYour name is %d characters!!!", strlen(mySecondStr));



    return 0;

}
