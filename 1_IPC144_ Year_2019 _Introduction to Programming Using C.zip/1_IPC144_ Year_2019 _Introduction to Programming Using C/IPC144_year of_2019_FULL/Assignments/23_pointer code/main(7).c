#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");
    int x = 10, y = 20;
    float a = 0.5, b = 0.1;
    char c = ';' ,d = 'Z';

    int* intPtr;
    float* fltPtr;
    char* chrPtr;

    printf("Variable names and addresses and values\n");
    printf("-----------------------------\n");
    printf("x%9d%5d\ny%9d%5d\na%9d%5.2f\nb%9d%5.2f\nc%9d%5c\nd%9d%5c", &x, x, &y, y, &a, a,  &b, b, &c, c, &d, d);

    intPtr = &x;
    fltPtr = &a;
    chrPtr = &d;

    printf("\n\nintPtr%9d\nfltPtr%9d\nchrPtr%9d", intPtr, fltPtr, chrPtr);

    printf("\n\n*intPtr:%d (expected to be the value of x)\n", *intPtr);
    printf("*(intPtr-1):%d (expected to be the value in y)", *(intPtr-1));

    *intPtr = 100; //actually means x = 100
    printf("\n\nx is now %d", x);
    *fltPtr = .01; //actually means a = 0.01
    printf("\na is now %.2f", a);

}
