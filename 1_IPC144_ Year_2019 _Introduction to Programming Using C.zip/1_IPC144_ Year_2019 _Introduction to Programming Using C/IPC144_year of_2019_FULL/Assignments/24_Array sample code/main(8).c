#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

int main()
{
    float array[SIZE];
    float array2[SIZE];
    float sum = 0;
    int i;

    for (i = 0 ; i < SIZE ; i = i + 1)
    {
        printf("Please enter element %d >", i + 1);
        scanf("%f", &array[i]);
    }

    printf("\n\nHere are the numbers you entered!: ");
    for (i = 0 ; i < SIZE ; i = i + 1)
        {
            printf("%.1f ", array[i]);
            sum = sum + array[i];
        }

    printf("\n\nHere are the numbers you entered in reverse order!: ");
    for (i = SIZE - 1 ; i >= 0 ;  i = i - 1)
        printf("%.1f ", array[i]);

    printf("\n\nThe average of array cells is %.1f", sum / SIZE);

    // making a copy of the first array in array2
    for ( i = 0 ; i < SIZE ; i = i + 1)
        array2[i] =  array[i] - sum/SIZE;

    printf("\n\nHere are the elements of the second array!: ");
    for (i = 0 ; i < SIZE ; i = i + 1)
            printf("%.1f ", array2[i]);

    // calculating the average of the second array
    sum = 0;
    for (i = 0 ; i < SIZE ; i = i + 1)
        sum = sum + array2[i];

    printf("\n\nThe average of array2 cells is %.1f", sum / SIZE);

}
