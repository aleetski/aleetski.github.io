#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STR_LEN 1024
#define STR_LEN 200

int main()
{
    int i, stringLength;
    char safeStr[MAX_STR_LEN];
    char str[STR_LEN + 1];
    char strRev[STR_LEN + 1];

    printf("Please enter a string (max %d chars) and I will reverse it in a second string!", STR_LEN);
    gets(safeStr);
    strncpy(str, safeStr, STR_LEN);
    printf("The string you enetered is %s", str);

    stringLength = strlen(str);

    delevop a code that copied the reverse of str in strRev

    printf("The string reversed is %s", strRev);
    return 0;
}
