#include <stdio.h>
#include <stdlib.h>

int main()
{
    float val1, val2, val3;
    float total, average;

    printf("Enter 3 numbers and I will calculate their sum and average>");
    scanf("%f %f %f", &val1 , &val2, &val3);

    total = val1 + val2 + val3;
    average = total /3;

    printf("Total = %.2f and the average = %.2f", total, average);
    return 0;
}
