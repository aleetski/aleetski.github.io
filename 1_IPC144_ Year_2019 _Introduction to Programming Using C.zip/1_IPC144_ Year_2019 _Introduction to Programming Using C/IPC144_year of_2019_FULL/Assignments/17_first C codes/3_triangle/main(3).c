#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float sideA, sideB, sideC;
    float area, perimeter;
    // Calculating the area and perimeter of a right angled triangle
    printf("Enter two sides of a right-angled triangle and I calculate its area and perimeter");
    printf("\nenter the two sided: ");
    scanf("%f %f", &sideA, &sideB);

    area = 0.5 * sideA * sideB;
    sideC = sqrt(sideA * sideA + sideB * sideB);
    perimeter = sideA + sideB + sideC;

    printf("The area of a triangle with sides %.1f and %.1f is %.1f and its perimeter is %.1f", sideA, sideB, area, perimeter);

    return 0;
}
