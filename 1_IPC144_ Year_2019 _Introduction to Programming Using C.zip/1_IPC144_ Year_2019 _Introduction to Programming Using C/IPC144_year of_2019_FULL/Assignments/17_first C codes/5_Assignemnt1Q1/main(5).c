#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    // gets a positive number smaller than 20 and prints that many stars
    int i, n;
    do
    {
        printf("\nEnter a number between 1 and 20. Enter 0 to end: > ");
        scanf("%d", &n);

        if (n <= 20 && n >= 0)
        {
            i = 1;
            while (i <= n)
            {
                printf("*");
                i = i + 1;
            }
        }
        else
        {
            printf("Invalid input");
        }
    } while (n!=0);
    printf("Thanks and Bye!");


        return 0;
}
