#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int i;

    i = 1;
    while (i <= 10)
    {

        printf("%d + %d = %d\n", i , 2 * i, 3 * i);
        i = i + 1;
    }
    return 0;
}
