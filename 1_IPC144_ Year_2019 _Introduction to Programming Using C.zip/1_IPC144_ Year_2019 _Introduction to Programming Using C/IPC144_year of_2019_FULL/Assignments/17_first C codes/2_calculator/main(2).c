#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Ask the user for two numbers and an operator (A for add, S for subtract, M for multiply
    // and D for division and calculate and print the result in a proper format
    // Example: if user input is 10 15 A, output should be 10 + 15 = 25
    float number1, number2;
    float result;
    char operation, sign;

    printf("Please enter two numbers > ");
    scanf("%f %f", &number1, &number2);

    printf("Please enter operation (A for add, S for subtract, M for multiply and D for division) > ");
    scanf(" %c", &operation);

    switch(operation)
    {
    case 'A':
    case 'a':
        result = number1 + number2;
        sign = '+';
        break;
    case 'S':
    case 's':
        result = number1 - number2;
        sign = '-';
        break;
    case 'M':
    case 'm':
        result = number1 * number2;
        sign = 'x';
        break;
    case 'D':
    case 'd':
        if (number2==0)
        {
            printf("Division by zero error!");
            sign='e';
        }
        else
        {
            result = number1 / number2;
            sign = '/';
        }
        break;
    default:
        printf("Invalid operation! Result cannot be calculated.");
        sign='e';
    }

    if (sign!='e')
        printf("%.2f %c %.2f = %.2f",number1, sign, number2, result);

    return 0;
}
