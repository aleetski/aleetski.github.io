#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STR_SIZE 256

struct phone {
  char brand[50];
  char model[50];
  float screenSize; //in inches
  char color[50];
  unsigned year;
  unsigned storage; //in gigabytes
};

void printPhone(struct phone x);
void getPhone(struct phone* x);
void phoneCpy(struct phone* dest, struct phone src);
int samePhone( struct phone ph1, struct phone ph2);
int samePhone2( struct phone ph1, struct phone ph2);

void main()
{
  
  struct phone myPhone;
  struct phone myPhone2;

  getPhone(&myPhone);
  printf("\n\n--------------------------\n\n");
  printPhone(myPhone);
  phoneCpy(&myPhone2, myPhone);
  strcat(myPhone2.model," Limited Edition");
  printf("\n\n--------------------------\n\n");
  printPhone(myPhone2);
  
  printf("\n\nPhone Comparison -- comparing myPhone and myPhone2\n");
  if (samePhone2(myPhone, myPhone2)==0)
    printf("These are the same phones!");
  else
    printf("These are not the same phones!");
}

void printPhone(struct phone x)
{
  printf("Phone Description: \n");
  printf("---------------------\n");
  printf ("%s %s\n", x.brand, x.model);
  printf("%d GB , %.1f inches\n", x.storage, x.screenSize);
  printf("%s , %d\n", x.color, x.year);
}

void phoneCpy(struct phone* dest, struct phone src)
{
  strcpy( dest -> brand, src.brand);
  strcpy( dest -> model, src.model);
  dest -> screenSize = src.screenSize;
  dest -> storage = src.storage;
  dest -> year = src.year;
  strcpy( dest -> color, src.color);
}

void getPhone(struct phone* x)
{
  char buffer[MAX_STR_SIZE];
  printf("Enter Phone Specs: \n");
  printf("--------------------\n");
  printf("Enter Brand: >");
  gets(buffer);
  strncpy(x -> brand, buffer, 49);
  printf("Enter Model: >");
  gets(buffer);
  strncpy(x -> model, buffer, 49);
  printf("Enter storage in giga bytes: >");
  scanf("%d", & x->storage);
  printf("Enter screen size in inches: >");
  scanf("%f", & x-> screenSize);
  printf("Enter year manufactured: >");
  scanf("%d", & x-> year);
  printf("Please enter color: >");
  getchar();
  gets(buffer);
  strncpy(x -> color, buffer, 49);
}

int samePhone( struct phone ph1, struct phone ph2)
{
  if (strcmp(ph1.brand, ph2.brand) == 0 &&
strcmp(ph1.model, ph2.model) ==0)
      return 0;
  else
      return 1;
}

int samePhone2( struct phone ph1, struct phone ph2)
{
  if (samePhone(ph1,ph2)==0 && ph1.screenSize==ph2.screenSize) 
    return 0;
  else 
    return 1;
}