#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE* fp;
    float x = 1.2345;
    fp = fopen ("bank.txt", "r");
    if (fp)
        printf("The file bank.txt exists");
    else
    {
        fp = fopen("bank.txt", "w");
        printf("bank.txt did NOT exist so I created it");
        //fprintf(fp, "I just wrote something into this file!");
        fputs("I just wrote something into this file!\n", fp);
        fputs("This is a second puts!", fp);
        fprintf(fp,"\n");
        fprintf(fp, "This is a float number %.2f", x);
    }

    fclose(fp);
}
