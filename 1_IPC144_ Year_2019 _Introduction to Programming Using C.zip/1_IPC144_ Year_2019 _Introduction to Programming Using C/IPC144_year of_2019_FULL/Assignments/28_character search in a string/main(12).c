#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STR_LEN 1024
#define STR_LEN 200

int main()
{
    int i, stringLength;
    char safeStr[MAX_STR_LEN];
    char str[STR_LEN + 1];
    char ch;
    //char strRev[STR_LEN + 1];

    printf("Please enter a string (max %d chars) ", STR_LEN);
    gets(safeStr);
    strncpy(str, safeStr, STR_LEN);
    printf("The string you entered is %s\n", str);
    printf("Please enter a character (case sensitive)");
    scanf(" %c", &ch);
    printf("\n\n");

    i = 0;
    while (str[i])
    {
        if (str[i] == ch)
            printf("%c was found at index %d\n" , ch , i);
        i = i + 1;
    }
    return 0;
}
